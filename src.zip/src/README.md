chrome-extension-append-html
============================

Small Chrome extension to inject Cliqueme Platform to any website.
